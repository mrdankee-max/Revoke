> [!IMPORTANT]
> Потерялись? Возможно вы ищите старую версию Revoke. Она расположена [здесь](https://github.com/KometTeam/KometOld).
---

<img src="assets/komet.png" width="100" alt="Revoke Logo">

# Revoke
Альтернативный FOSS клиент для мессенджера MAX

## Установка
[Последний релиз](https://github.com/KometTeam/Revoke/releases/latest) / [Telegram Канал](https://t.me/TeamKomet) 

## Сборка из исходного кода
```console
$ flutter build [windows|linux] [--release]
```

## Хотите помочь?
Нашли ошибку и сами её исправили? Сделайте Pull-Request.<br/>

---
Revoke — форк проекта [Komet](https://github.com/KometTeam/Komet) (GPLv3). Лицензия и авторство оригинала сохранены.
